># `Compose notification`
>![image](https://github.com/user-attachments/assets/062c75ff-2941-4515-9d2b-84547767687a)

```html

<script type="module">
  // Import the functions you need from the SDKs you need
  import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.4/firebase-app.js";
  import { getAnalytics } from "https://www.gstatic.com/firebasejs/10.12.4/firebase-analytics.js";
  // TODO: Add SDKs for Firebase products that you want to use
  // https://firebase.google.com/docs/web/setup#available-libraries

  // Your web app's Firebase configuration
  // For Firebase JS SDK v7.20.0 and later, measurementId is optional
  const firebaseConfig = {
    apiKey: "AIzaSyDEff**************Yp1JMKf7t2wlA",
    authDomain: "fir-push-not*****************baseapp.com",
    projectId: "fir-pus*****************13",
    storageBucket: "fir-pu*****************pspot.com",
    messagingSenderId: "279*******552",
    appId: "1:279392*****************6fb7174ed",
    measurementId: "G-TZ******SRE"
  };

  // Initialize Firebase
  const app = initializeApp(firebaseConfig);
  const analytics = getAnalytics(app);
</script>
```

>## `Web configuration`
>[![image](https://github.com/user-attachments/assets/65eecfbd-49f5-4d84-a81d-2351a1165955)](https://console.firebase.google.com/project/fir-push-notification-85613/settings/cloudmessaging/web:M2MxY2RmNjgtNzBkMS00MmI0LWI2MjctYzRmYmM4MWFmN2Y4)
