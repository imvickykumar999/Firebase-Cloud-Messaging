from flask import Flask, jsonify, render_template, request
import firebase_admin
from firebase_admin import credentials

app = Flask(__name__)

# Initialize Firebase Admin SDK
cred = credentials.Certificate("serviceAccountKey.json")
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://fir-push-notification-85613-default-rtdb.firebaseio.com'
})

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/firebase-config')
def get_firebase_config():
    config = {
        'apiKey': "AIzaSyDEffV60DqptX5isXVzlhYp1JMKf7t2wlA",
        'authDomain': "fir-push-notification-85613.firebaseapp.com",
        'projectId': "fir-push-notification-85613",
        'storageBucket': "fir-push-notification-85613.appspot.com",
        'messagingSenderId': "279392742552",
        'appId': "1:279392742552:web:df183eb0e8c256fb7174ed",
        'measurementId': "G-TZVKHMQSRE",
        'vapidKey': "BI_V_6JdbJ6jpCBSLqZHyhA6r96BG5qa3RbvNz5mq20MYSkFmzt5rDTtrZ6Z6PoaOrYp3REDVpIlu5uzNIxCqEk"
    }
    return jsonify(config)

@app.route('/send', methods=['POST'])
def send():
    registration_id = request.form.get('registration_id')
    title = request.form.get('title')
    body = request.form.get('body')
    
    # Here you should implement the logic to send notification using the fetched registration ID
    # For the sake of example, we'll just print the values
    print(f"Registration ID: {registration_id}")
    print(f"Title: {title}")
    print(f"Body: {body}")
    
    # Simulate sending notification and return a success response
    response = {
        "message_id": "example_message_id",
        "status": "Success",
        "info": "Notification has been sent"
    }
    
    return render_template('result.html', 
                           registration_id=registration_id, 
                           message_title=title, 
                           message_desc=body, 
                           response=response)

@app.route('/firebase-messaging-sw.js')
def service_worker():
    return send_from_directory('static', 'firebase-messaging-sw.js')

if __name__ == '__main__':
    app.run(debug=True)

