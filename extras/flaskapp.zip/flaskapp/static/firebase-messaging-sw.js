// [START messaging_sw]
importScripts('https://www.gstatic.com/firebasejs/8.6.3/firebase-app.js');
importScripts('https://www.gstatic.com/firebasejs/8.6.3/firebase-messaging.js');

firebase.initializeApp({
    apiKey: "AIzaSyDEffV60DqptX5isXVzlhYp1JMKf7t2wlA",
    authDomain: "fir-push-notification-85613.firebaseapp.com",
    projectId: "fir-push-notification-85613",
    storageBucket: "fir-push-notification-85613.appspot.com",
    messagingSenderId: "279392742552",
    appId: "1:279392742552:web:df183eb0e8c256fb7174ed",
    measurementId: "G-TZVKHMQSRE"
});

const messaging = firebase.messaging();

messaging.onBackgroundMessage(function(payload) {
  console.log('[firebase-messaging-sw.js] Received background message ', payload);
  // Customize notification here
  const notificationTitle = 'Background Message Title';
  const notificationOptions = {
    body: 'Background Message body.',
    icon: '/firebase-logo.png'
  };

  self.registration.showNotification(notificationTitle,
    notificationOptions);
});
// [END messaging_sw]

