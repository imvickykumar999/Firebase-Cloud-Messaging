from django.http.request import HttpHeaders
from django.shortcuts import render

from django.http import HttpResponse
import requests
import json

from google.oauth2 import service_account
import google.auth.transport.requests

def get_access_token():
    credentials = service_account.Credentials.from_service_account_file(
        'fir-push-notification-85613-6988faf5d271.json',
        scopes=['https://www.googleapis.com/auth/firebase.messaging']
    )
    request = google.auth.transport.requests.Request()
    credentials.refresh(request)
    return credentials.token

def send_notification(registration_ids , message_title , message_desc):
    # fcm_api = "ya29.a0AXooCgvTehLehSNosJB1JhFpvfYS-h6v2944lTFzZI0xzFAQSOWuRPCDlkqvTMn-cCfjJgUHdwLOUxfbDIpJ2DIFGor9ggX3y8H2eB1g6NT2SY1hbGxTNv2uQ0EsWMd7Ij7sUV6mNrnTvRtGUqiBE-HGHCDQtaX2E1DSaCgYKAZ0SARESFQHGX2MiWYbNHvcUb1AgXnSJgeZ8OA0171"
    
    fcm_api = get_access_token()  # Get the OAuth 2.0 access token
    url = "https://fcm.googleapis.com/v1/projects/fir-push-notification-85613/messages:send"
    
    headers = {
    "Content-Type":"application/json",
    "Authorization": 'Bearer '+fcm_api}

    payload = {
        "message":{
            "token":registration_ids,
            "notification":{
                "body":message_desc,
                "title":message_title,
                # "image" : "https://i.ytimg.com/vi/m5WUPHRgdOA/hqdefault.jpg?sqp=-oaymwEXCOADEI4CSFryq4qpAwkIARUAAIhCGAE=&rs=AOn4CLDwz-yjKEdwxvKjwMANGk5BedCOXQ",
                # "icon": "https://yt3.ggpht.com/ytc/AKedOLSMvoy4DeAVkMSAuiuaBdIGKC7a5Ib75bKzKO3jHg=s900-c-k-c0x00ffffff-no-rj",
            }
        }
    }

    result = requests.post(url,  data=json.dumps(payload), headers=headers )
    data = result.json()

    print(data)
    return data

def index(request):
    return render(request , 'index.html')

def send(request):
    resgistration  = "dF8A2vqxUKQPjV27rLXtiO:APA91bGla1qCeVjVXTVqqnsHsPLk5N8icT1n9XzDDxlBnOWaYZmRiHtS_yPU8QzsTHVLIWT_Adu3eI3kGR4I6YWNk9DNx8NsLVy_XjhNCVltg9KQWX74Om5nPBX7Km9JSSEDDNX3IC_l"
    result = send_notification(resgistration , 'Code Keen added a new video' , 'Code Keen new video alert')

    data = json.dumps(result)
    return HttpResponse(data)


def showFirebaseJS(request):
    data='importScripts("https://www.gstatic.com/firebasejs/8.2.0/firebase-app.js");' \
         'importScripts("https://www.gstatic.com/firebasejs/8.2.0/firebase-messaging.js"); ' \
         'var firebaseConfig = {' \
         '        apiKey: "AIzaSyDEffV60DqptX5isXVzlhYp1JMKf7t2wlA",' \
         '        authDomain: "fir-push-notification-85613.firebaseapp.com",' \
         '        projectId: "fir-push-notification-85613",' \
         '        storageBucket: "fir-push-notification-85613.appspot.com",' \
         '        messagingSenderId: "279392742552",' \
         '        appId: "1:279392742552:web:df183eb0e8c256fb7174ed",' \
         '        measurementId: "G-TZVKHMQSRE"' \
         ' };' \
         'firebase.initializeApp(firebaseConfig);' \
         'const messaging=firebase.messaging();' \
         'messaging.setBackgroundMessageHandler(function (payload) {' \
         '    console.log(payload);' \
         '    const notification=JSON.parse(payload);' \
         '    const notificationOption={' \
         '        body:notification.body,' \
         '        icon:notification.icon' \
         '    };' \
         '    return self.registration.showNotification(payload.notification.title,notificationOption);' \
         '});'

    return HttpResponse(data,content_type="text/javascript")
